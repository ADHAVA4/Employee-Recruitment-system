/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.io.*;
/**
 *
 * @author Dell
 */
public class Update implements Serializable{
   
    private String iD;
  
    public String getID() {
        return iD;
    }

    public void setID(String iD) {
        this.iD = iD;
    }  
 }

